docker build -t game .
